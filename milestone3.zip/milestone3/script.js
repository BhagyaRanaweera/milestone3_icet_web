// script.js

document.addEventListener('DOMContentLoaded', () => {
    // Load menu items dynamically
    fetch('data/menu-items.json')
        .then(response => response.json())
        .then(data => {
            const menuItemsDiv = document.getElementById('menu-items');
            if (menuItemsDiv) {
                data.items.forEach(item => {
                    const itemDiv = document.createElement('div');
                    itemDiv.className = 'menu-item';
                    itemDiv.innerHTML = `
                        <h3>${item.name}</h3>
                        <p>Price: ${item.price}</p>
                        <p>Category: ${item.category}</p>
                    `;
                    menuItemsDiv.appendChild(itemDiv);
                });
            }
        }).catch(error => {
            console.error('Error loading menu items:', error);
        });
});
