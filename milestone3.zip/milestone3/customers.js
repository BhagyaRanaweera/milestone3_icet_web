// customers.js

document.addEventListener('DOMContentLoaded', () => {
    const customerForm = document.getElementById('customer-form');
    const customersList = document.getElementById('customers');
    const errorMessage = document.getElementById('error-message');
    let customers = [];

    customerForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const customerId = document.getElementById('customer-id').value;
        const customerName = document.getElementById('customer-name').value;

        if (!customerId || !customerName) {
            errorMessage.textContent = 'Please enter both customer ID and name.';
            return;
        }

        errorMessage.textContent = '';

        const existingCustomer = customers.find(c => c.id === customerId);
        if (existingCustomer) {
            existingCustomer.name = customerName;
        } else {
            customers.push({ id: customerId, name: customerName });
        }

        updateCustomerList();
        customerForm.reset();
    });

    function updateCustomerList() {
        customersList.innerHTML = '';
        customers.forEach(customer => {
            const listItem = document.createElement('li');
            listItem.textContent = `ID: ${customer.id}, Name: ${customer.name}`;
            customersList.appendChild(listItem);
        });
    }
});
